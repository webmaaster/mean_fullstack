const express = require('express')


const app = express()
app.use(express.static(__dirname + '/publicService/dist/publicService'))


app.get('/', (req, res)=>{

})

app.listen(8000)
console.log("The server is running on : 8000")